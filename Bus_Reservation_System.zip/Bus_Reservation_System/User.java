public class User
{
	String email;
	String phone;
	String username;
	String password;
	public User(){}
	public User(String username, String password)
	{
		this.username = username;
		this.password = password;
	}
	
} 
public class TicketPrice
{
	String seats;
	String prices;
	String payments;

	TicketPrice()
	{

	}
	TicketPrice(String seats, String prices,String payments)
	{
		this.seats = seats;
		this.prices = prices;
		this.payments = payments;
	}
}
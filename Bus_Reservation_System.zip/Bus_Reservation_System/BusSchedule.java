public class BusSchedule
{
	String from;
	String to;
	String date;
	String month;
	String year;
	String time;
	public BusSchedule(){}
	public BusSchedule(String from, String to,String date, String month, String year, String time)
	{
		this.from = from;
		this.to = to;
		this.date = date;
		this.month = month;
		this.year = year;
		this.time = time;
	}
	
} 
public class Admin 
{
	String adminName;
	String adminPassword;

	public Admin()
	{
		
	}
	public Admin(String adminName,String adminPassword)
	{
		this.adminName=adminName;
		this.adminPassword=adminPassword;
	}
}